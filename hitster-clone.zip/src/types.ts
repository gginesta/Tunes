export type Screen = 'home' | 'lobby' | 'game' | 'results';

export interface Player {
  id: string;
  name: string;
  isHost: boolean;
  cards: Card[];
  tokens: number;
}

export interface Card {
  id: string;
  title: string;
  artist: string;
  year: number;
  colorClass: string;
}

export interface GameState {
  screen: Screen;
  roomCode: string;
  players: Player[];
  currentPlayerId: string;
  hostId: string;
  targetCards: number;
  gameMode: string;
  currentCard: Card | null;
  round: number;
}
