import React from 'react';
import { Users, Crown, Settings, LogOut, Play } from 'lucide-react';
import { motion } from 'motion/react';
import { GameState } from '../types';

interface LobbyProps {
  gameState: GameState;
  currentPlayerId: string;
  onStart: () => void;
  onLeave: () => void;
  onUpdateSettings: (settings: Partial<GameState>) => void;
}

export function Lobby({ gameState, currentPlayerId, onStart, onLeave, onUpdateSettings }: LobbyProps) {
  const isHost = gameState.hostId === currentPlayerId;

  return (
    <div className="flex flex-col min-h-screen p-6 text-white bg-[#1a1a2e]">
      <div className="flex justify-between items-center mb-8">
        <button onClick={onLeave} className="p-2 bg-white/5 rounded-full hover:bg-white/10 transition-colors">
          <LogOut className="w-5 h-5 text-gray-400" />
        </button>
        <div className="text-center">
          <p className="text-xs text-gray-400 uppercase tracking-widest font-bold mb-1">Room Code</p>
          <h2 className="text-4xl font-black tracking-widest text-[#1DB954]">{gameState.roomCode}</h2>
        </div>
        <div className="w-9"></div> {/* Spacer for centering */}
      </div>

      <div className="flex-1 space-y-8">
        <div className="bg-white/5 rounded-3xl p-6 border border-white/10">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold flex items-center gap-2">
              <Users className="w-5 h-5 text-[#1DB954]" />
              Players
            </h3>
            <span className="text-sm text-gray-400 font-medium">{gameState.players.length}/10</span>
          </div>
          
          <div className="space-y-3">
            {gameState.players.map((player) => (
              <motion.div 
                key={player.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center justify-between bg-black/20 p-3 rounded-2xl"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#1DB954] to-blue-600 flex items-center justify-center font-bold text-lg">
                    {player.name.charAt(0).toUpperCase()}
                  </div>
                  <span className="font-medium text-lg">{player.name}</span>
                  {player.id === currentPlayerId && <span className="text-xs bg-white/10 px-2 py-1 rounded-full text-gray-300">You</span>}
                </div>
                {player.isHost && <Crown className="w-5 h-5 text-[#FFD700]" />}
              </motion.div>
            ))}
          </div>
        </div>

        {isHost ? (
          <div className="bg-white/5 rounded-3xl p-6 border border-white/10 space-y-6">
            <h3 className="text-lg font-bold flex items-center gap-2">
              <Settings className="w-5 h-5 text-gray-400" />
              Game Settings
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="text-sm text-gray-400 font-medium mb-2 block">Game Mode</label>
                <div className="grid grid-cols-2 gap-2">
                  {['Original', 'Pro', 'Expert', 'Co-op'].map(mode => (
                    <button
                      key={mode}
                      onClick={() => onUpdateSettings({ gameMode: mode })}
                      className={`py-2 px-3 rounded-xl text-sm font-medium transition-all ${
                        gameState.gameMode === mode 
                          ? 'bg-[#1DB954] text-black' 
                          : 'bg-black/30 text-gray-300 hover:bg-black/50'
                      }`}
                    >
                      {mode}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm text-gray-400 font-medium">Cards to Win</label>
                  <span className="text-[#1DB954] font-bold">{gameState.targetCards}</span>
                </div>
                <input 
                  type="range" 
                  min="5" 
                  max="15" 
                  value={gameState.targetCards}
                  onChange={(e) => onUpdateSettings({ targetCards: parseInt(e.target.value) })}
                  className="w-full accent-[#1DB954]"
                />
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-12 text-gray-400">
            <div className="animate-pulse flex space-x-2 mb-4">
              <div className="w-3 h-3 bg-[#1DB954] rounded-full"></div>
              <div className="w-3 h-3 bg-[#1DB954] rounded-full" style={{ animationDelay: '200ms' }}></div>
              <div className="w-3 h-3 bg-[#1DB954] rounded-full" style={{ animationDelay: '400ms' }}></div>
            </div>
            <p className="font-medium">Waiting for host to start...</p>
          </div>
        )}
      </div>

      {isHost && (
        <div className="mt-6">
          <button 
            onClick={onStart}
            disabled={gameState.players.length < 2}
            className="w-full bg-[#1DB954] hover:bg-[#1ed760] disabled:opacity-50 disabled:hover:bg-[#1DB954] text-black font-black text-xl py-5 rounded-2xl flex items-center justify-center gap-2 shadow-[0_0_30px_rgba(29,185,84,0.4)] transition-all transform active:scale-95"
          >
            <Play className="w-6 h-6 fill-current" />
            START GAME
          </button>
        </div>
      )}
    </div>
  );
}
