import React, { useState } from 'react';
import { Music, Headphones } from 'lucide-react';
import { motion } from 'motion/react';

interface HomeProps {
  onHost: (name: string) => void;
  onJoin: (name: string, code: string) => void;
}

export function Home({ onHost, onJoin }: HomeProps) {
  const [name, setName] = useState('');
  const [showJoin, setShowJoin] = useState(false);
  const [showSpotify, setShowSpotify] = useState(false);
  const [code, setCode] = useState(['', '', '', '']);

  const handleCodeChange = (index: number, value: string) => {
    if (value.length > 1) return;
    const newCode = [...code];
    newCode[index] = value.toUpperCase();
    setCode(newCode);
    
    // Auto-advance focus
    if (value && index < 3) {
      const nextInput = document.getElementById(`code-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleCodeKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      const prevInput = document.getElementById(`code-${index - 1}`);
      prevInput?.focus();
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-6 text-white bg-[#1a1a2e]">
      <motion.div 
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="flex flex-col items-center mb-12"
      >
        <div className="relative">
          <div className="absolute inset-0 bg-[#1DB954] blur-xl opacity-20 rounded-full"></div>
          <Music className="w-24 h-24 text-[#1DB954] mb-4 relative z-10" />
        </div>
        <h1 className="text-5xl font-black tracking-tighter bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
          HITSTER
        </h1>
        <p className="text-gray-400 mt-2 font-medium tracking-wide uppercase text-sm">The Music Party Game</p>
      </motion.div>

      <div className="w-full max-w-sm space-y-6">
        <div className="space-y-2">
          <label className="text-sm font-semibold text-gray-300 uppercase tracking-wider ml-1">Your Name</label>
          <input 
            type="text" 
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter your nickname..."
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#1DB954] focus:border-transparent transition-all"
          />
        </div>

        {!showJoin && !showSpotify ? (
          <div className="space-y-4 pt-4">
            <button 
              onClick={() => name && setShowSpotify(true)}
              disabled={!name}
              className="w-full bg-[#1DB954] hover:bg-[#1ed760] disabled:opacity-50 disabled:hover:bg-[#1DB954] text-black font-bold text-lg py-4 px-6 rounded-2xl flex items-center justify-center gap-3 transition-all transform active:scale-95 shadow-[0_0_20px_rgba(29,185,84,0.3)]"
            >
              <Headphones className="w-6 h-6" />
              Host Game
            </button>
            <button 
              onClick={() => setShowJoin(true)}
              disabled={!name}
              className="w-full bg-white/10 hover:bg-white/15 disabled:opacity-50 text-white font-bold text-lg py-4 px-6 rounded-2xl transition-all transform active:scale-95"
            >
              Join Game
            </button>
          </div>
        ) : showSpotify ? (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="space-y-6 pt-4 text-center"
          >
            <p className="text-gray-300 mb-4">Hosts need Spotify Premium to play music for the room.</p>
            <button 
              onClick={() => onHost(name)}
              className="w-full bg-[#1DB954] hover:bg-[#1ed760] text-black font-bold text-lg py-4 px-6 rounded-2xl flex items-center justify-center gap-3 transition-all transform active:scale-95 shadow-[0_0_20px_rgba(29,185,84,0.3)]"
            >
              Connect to Spotify
            </button>
            <button 
              onClick={() => setShowSpotify(false)}
              className="w-full bg-transparent text-gray-400 hover:text-white font-bold py-2 transition-all"
            >
              Cancel
            </button>
          </motion.div>
        ) : (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="space-y-6 pt-4"
          >
            <div className="space-y-3">
              <label className="text-sm font-semibold text-gray-300 uppercase tracking-wider ml-1 text-center block">Enter Room Code</label>
              <div className="flex justify-between gap-3">
                {[0, 1, 2, 3].map((i) => (
                  <input
                    key={i}
                    id={`code-${i}`}
                    type="text"
                    maxLength={1}
                    value={code[i]}
                    onChange={(e) => handleCodeChange(i, e.target.value)}
                    onKeyDown={(e) => handleCodeKeyDown(i, e)}
                    className="w-16 h-20 bg-white/5 border-2 border-white/10 rounded-2xl text-center text-3xl font-black text-white focus:outline-none focus:border-[#1DB954] focus:bg-[#1DB954]/10 transition-all uppercase"
                  />
                ))}
              </div>
            </div>
            <div className="flex gap-3">
              <button 
                onClick={() => setShowJoin(false)}
                className="flex-1 bg-white/10 hover:bg-white/15 text-white font-bold py-4 rounded-2xl transition-all"
              >
                Back
              </button>
              <button 
                onClick={() => {
                  const fullCode = code.join('');
                  if (fullCode.length === 4) onJoin(name, fullCode);
                }}
                disabled={code.join('').length !== 4}
                className="flex-[2] bg-[#1DB954] hover:bg-[#1ed760] disabled:opacity-50 text-black font-bold py-4 rounded-2xl transition-all shadow-[0_0_20px_rgba(29,185,84,0.3)]"
              >
                Join Room
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
