import React, { useState } from 'react';
import { Disc, Coins, Check, X, SkipForward, AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GameState } from '../types';

interface GameProps {
  gameState: GameState;
  currentPlayerId: string;
  onPlaceCard: (index: number) => void;
  onSkip: () => void;
  onChallenge: () => void;
}

export function Game({ gameState, currentPlayerId, onPlaceCard, onSkip, onChallenge }: GameProps) {
  const isActivePlayer = gameState.currentPlayerId === currentPlayerId;
  const activePlayer = gameState.players.find(p => p.id === gameState.currentPlayerId);
  const me = gameState.players.find(p => p.id === currentPlayerId);
  
  const [guessTitle, setGuessTitle] = useState('');
  const [guessArtist, setGuessArtist] = useState('');
  const [showReveal, setShowReveal] = useState(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);

  // Mock reveal animation
  const handlePlaceCard = (index: number) => {
    setShowReveal(true);
    // Simulate checking correctness (random for prototype)
    const correct = Math.random() > 0.3;
    setIsCorrect(correct);
    
    setTimeout(() => {
      setShowReveal(false);
      setIsCorrect(null);
      onPlaceCard(index);
    }, 2500);
  };

  if (!activePlayer || !me) return null;

  return (
    <div className="flex flex-col h-screen text-white bg-[#1a1a2e] overflow-hidden">
      {/* Top Bar */}
      <div className="flex justify-between items-center p-4 bg-black/30 backdrop-blur-md border-b border-white/5 z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center font-bold">
            {activePlayer.name.charAt(0).toUpperCase()}
          </div>
          <div>
            <p className="text-xs text-gray-400 uppercase tracking-wider font-bold">Round {gameState.round}</p>
            <p className="font-bold text-[#1DB954]">{isActivePlayer ? 'Your Turn' : `${activePlayer.name}'s Turn`}</p>
          </div>
        </div>
        
        <div className="flex gap-4">
          {gameState.players.map(p => (
            <div key={p.id} className={`flex flex-col items-center ${p.id === currentPlayerId ? 'opacity-100' : 'opacity-50'}`}>
              <div className="flex items-center gap-1 text-xs font-bold">
                <div className="w-2 h-3 bg-white/20 rounded-sm"></div>
                {p.cards.length}/{gameState.targetCards}
              </div>
              <div className="flex items-center gap-1 text-xs text-[#FFD700] font-bold">
                <Coins className="w-3 h-3" />
                {p.tokens}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Center Area: Current Card */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 relative">
        <AnimatePresence mode="wait">
          {gameState.currentCard && (
            <motion.div
              key={gameState.currentCard.id}
              initial={{ scale: 0.8, opacity: 0, y: 50 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.8, opacity: 0, y: -50 }}
              className={`w-64 aspect-square rounded-3xl p-6 flex flex-col items-center justify-center relative overflow-hidden shadow-2xl ${
                showReveal 
                  ? isCorrect 
                    ? 'bg-gradient-to-br from-green-500 to-emerald-700 shadow-[0_0_50px_rgba(34,197,94,0.5)]' 
                    : 'bg-gradient-to-br from-red-500 to-rose-700 shadow-[0_0_50px_rgba(239,68,68,0.5)]'
                  : 'bg-gradient-to-br from-blue-600 to-indigo-900'
              }`}
            >
              {/* Vinyl record background decoration */}
              <div className="absolute -right-12 -bottom-12 opacity-20">
                <Disc className="w-48 h-48" />
              </div>

              {!showReveal ? (
                <>
                  <div className="absolute top-4 left-4 right-4 flex justify-between items-center">
                    <div className="flex gap-1">
                      <span className="w-1 h-3 bg-[#1DB954] rounded-full animate-pulse"></span>
                      <span className="w-1 h-4 bg-[#1DB954] rounded-full animate-pulse" style={{ animationDelay: '150ms' }}></span>
                      <span className="w-1 h-2 bg-[#1DB954] rounded-full animate-pulse" style={{ animationDelay: '300ms' }}></span>
                    </div>
                    <span className="text-xs font-bold text-white/70 uppercase tracking-widest">Now Playing</span>
                  </div>
                  <h2 className="text-6xl font-black text-white/90 mt-4">?</h2>
                  <p className="text-white/50 font-medium mt-2">Guess the year</p>
                </>
              ) : (
                <motion.div 
                  initial={{ rotateY: 90 }}
                  animate={{ rotateY: 0 }}
                  className="text-center z-10"
                >
                  <h2 className="text-5xl font-black mb-2">{gameState.currentCard.year}</h2>
                  <p className="text-lg font-bold leading-tight">{gameState.currentCard.title}</p>
                  <p className="text-sm text-white/80">{gameState.currentCard.artist}</p>
                  
                  <div className="mt-6">
                    {isCorrect ? (
                      <div className="flex items-center justify-center gap-2 text-white bg-black/20 px-4 py-2 rounded-full">
                        <Check className="w-5 h-5" /> Correct!
                      </div>
                    ) : (
                      <div className="flex items-center justify-center gap-2 text-white bg-black/20 px-4 py-2 rounded-full">
                        <X className="w-5 h-5" /> Incorrect
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Optional Guess Inputs for Active Player */}
        {isActivePlayer && !showReveal && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 w-full max-w-xs space-y-3"
          >
            <input 
              type="text" 
              placeholder="Guess Title (Optional)" 
              value={guessTitle}
              onChange={e => setGuessTitle(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#1DB954]"
            />
            <input 
              type="text" 
              placeholder="Guess Artist (Optional)" 
              value={guessArtist}
              onChange={e => setGuessArtist(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#1DB954]"
            />
          </motion.div>
        )}
        
        {!isActivePlayer && !showReveal && (
          <div className="mt-8 text-center">
            <p className="text-gray-400 mb-4">Waiting for {activePlayer.name} to place the card...</p>
            <button 
              onClick={onChallenge}
              disabled={me.tokens < 1}
              className="bg-red-500/20 hover:bg-red-500/30 text-red-500 border border-red-500/50 font-bold py-3 px-6 rounded-2xl flex items-center gap-2 mx-auto transition-all disabled:opacity-50"
            >
              <AlertTriangle className="w-5 h-5" />
              Challenge! (1 Token)
            </button>
          </div>
        )}
      </div>

      {/* Bottom Area: Timeline */}
      <div className={`bg-black/40 backdrop-blur-xl border-t border-white/10 p-6 transition-opacity duration-500 ${!isActivePlayer ? 'opacity-50 pointer-events-none' : ''}`}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-gray-300 uppercase tracking-widest text-sm">
            {isActivePlayer ? 'Your Timeline' : `${activePlayer.name}'s Timeline`}
          </h3>
          {isActivePlayer && (
            <button 
              onClick={onSkip}
              className="flex items-center gap-1 text-xs font-bold text-gray-400 hover:text-white bg-white/5 px-3 py-1.5 rounded-full transition-colors"
            >
              <SkipForward className="w-3 h-3" />
              Skip (1 Token)
            </button>
          )}
        </div>

        <div className="flex overflow-x-auto pb-4 hide-scrollbar items-center min-h-[160px]">
          {/* Timeline Drop Zones and Cards */}
          <DropZone index={0} onDrop={() => handlePlaceCard(0)} active={isActivePlayer && !showReveal} />
          
          {activePlayer.cards.map((card, idx) => (
            <React.Fragment key={card.id}>
              <motion.div 
                layout
                initial={{ opacity: 0, scale: 0.8, y: -20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                transition={{ type: "spring", stiffness: 300, damping: 25 }}
                className={`flex-shrink-0 w-28 h-36 rounded-2xl p-3 flex flex-col justify-between ${card.colorClass} shadow-lg relative`}
              >
                <div className="absolute inset-0 bg-black/20 rounded-2xl"></div>
                <div className="relative z-10">
                  <h4 className="font-black text-2xl text-white/90">{card.year}</h4>
                </div>
                <div className="relative z-10">
                  <p className="text-xs font-bold text-white leading-tight line-clamp-2">{card.title}</p>
                  <p className="text-[10px] text-white/70 truncate">{card.artist}</p>
                </div>
              </motion.div>
              <DropZone index={idx + 1} onDrop={() => handlePlaceCard(idx + 1)} active={isActivePlayer && !showReveal} />
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}

function DropZone({ index, onDrop, active }: { index: number, onDrop: () => void, active: boolean }) {
  return (
    <motion.button 
      layout
      onClick={onDrop}
      disabled={!active}
      className={`flex-shrink-0 w-12 h-24 mx-2 rounded-xl border-2 border-dashed flex items-center justify-center transition-all ${
        active 
          ? 'border-[#1DB954]/50 hover:border-[#1DB954] hover:bg-[#1DB954]/10 cursor-pointer' 
          : 'border-white/10 opacity-0'
      }`}
    >
      {active && <div className="w-6 h-6 rounded-full bg-[#1DB954]/20 flex items-center justify-center text-[#1DB954] font-bold">+</div>}
    </motion.button>
  );
}
