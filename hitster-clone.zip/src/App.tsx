/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Home } from './components/Home';
import { Lobby } from './components/Lobby';
import { Game } from './components/Game';
import { Results } from './components/Results';
import { GameState, Player, Card } from './types';

// Mock data
const MOCK_CARDS: Card[] = [
  { id: 'c1', title: 'Bohemian Rhapsody', artist: 'Queen', year: 1975, colorClass: 'bg-gradient-to-br from-purple-600 to-blue-600' },
  { id: 'c2', title: 'Billie Jean', artist: 'Michael Jackson', year: 1983, colorClass: 'bg-gradient-to-br from-red-600 to-orange-600' },
  { id: 'c3', title: 'Smells Like Teen Spirit', artist: 'Nirvana', year: 1991, colorClass: 'bg-gradient-to-br from-green-600 to-teal-600' },
  { id: 'c4', title: 'Hey Ya!', artist: 'Outkast', year: 2003, colorClass: 'bg-gradient-to-br from-yellow-500 to-orange-500' },
  { id: 'c5', title: 'Uptown Funk', artist: 'Mark Ronson ft. Bruno Mars', year: 2014, colorClass: 'bg-gradient-to-br from-pink-500 to-rose-500' },
  { id: 'c6', title: 'Blinding Lights', artist: 'The Weeknd', year: 2019, colorClass: 'bg-gradient-to-br from-indigo-600 to-purple-600' },
];

const generateRoomCode = () => Math.random().toString(36).substring(2, 6).toUpperCase();

export default function App() {
  const [currentPlayerId, setCurrentPlayerId] = useState<string>('');
  const [gameState, setGameState] = useState<GameState>({
    screen: 'home',
    roomCode: '',
    players: [],
    currentPlayerId: '',
    hostId: '',
    targetCards: 10,
    gameMode: 'Original',
    currentCard: null,
    round: 1,
  });

  const handleHost = (name: string) => {
    const id = Math.random().toString(36).substring(7);
    setCurrentPlayerId(id);
    setGameState({
      ...gameState,
      screen: 'lobby',
      roomCode: generateRoomCode(),
      hostId: id,
      players: [{ id, name, isHost: true, cards: [], tokens: 3 }],
    });
  };

  const handleJoin = (name: string, code: string) => {
    const id = Math.random().toString(36).substring(7);
    setCurrentPlayerId(id);
    setGameState({
      ...gameState,
      screen: 'lobby',
      roomCode: code,
      players: [
        ...gameState.players,
        { id, name, isHost: false, cards: [], tokens: 3 }
      ],
    });
  };

  const handleLeave = () => {
    setGameState({ ...gameState, screen: 'home', roomCode: '', players: [] });
    setCurrentPlayerId('');
  };

  const handleUpdateSettings = (settings: Partial<GameState>) => {
    setGameState({ ...gameState, ...settings });
  };

  const handleStart = () => {
    // Give each player 1 starting card
    const playersWithStartingCard = gameState.players.map(p => ({
      ...p,
      cards: [MOCK_CARDS[Math.floor(Math.random() * MOCK_CARDS.length)]]
    }));

    setGameState({
      ...gameState,
      screen: 'game',
      players: playersWithStartingCard,
      currentPlayerId: playersWithStartingCard[0].id,
      currentCard: MOCK_CARDS[Math.floor(Math.random() * MOCK_CARDS.length)],
      round: 1,
    });
  };

  const nextTurn = (players: Player[]) => {
    const currentIndex = players.findIndex(p => p.id === gameState.currentPlayerId);
    const nextIndex = (currentIndex + 1) % players.length;
    const nextPlayerId = players[nextIndex].id;
    
    // Check win condition
    const winner = players.find(p => p.cards.length >= gameState.targetCards);
    if (winner) {
      setGameState({
        ...gameState,
        players,
        screen: 'results'
      });
      return;
    }

    setGameState({
      ...gameState,
      players,
      currentPlayerId: nextPlayerId,
      currentCard: MOCK_CARDS[Math.floor(Math.random() * MOCK_CARDS.length)],
      round: nextIndex === 0 ? gameState.round + 1 : gameState.round,
    });
  };

  const handlePlaceCard = (index: number) => {
    if (!gameState.currentCard) return;
    
    const updatedPlayers = gameState.players.map(p => {
      if (p.id === gameState.currentPlayerId) {
        const newCards = [...p.cards];
        // Insert at index and sort by year to simulate correct placement
        newCards.splice(index, 0, gameState.currentCard!);
        newCards.sort((a, b) => a.year - b.year);
        return { ...p, cards: newCards };
      }
      return p;
    });

    nextTurn(updatedPlayers);
  };

  const handleSkip = () => {
    const updatedPlayers = gameState.players.map(p => {
      if (p.id === gameState.currentPlayerId) {
        return { ...p, tokens: Math.max(0, p.tokens - 1) };
      }
      return p;
    });
    nextTurn(updatedPlayers);
  };

  const handleChallenge = () => {
    const updatedPlayers = gameState.players.map(p => {
      if (p.id === currentPlayerId) {
        return { ...p, tokens: Math.max(0, p.tokens - 1) };
      }
      return p;
    });
    setGameState({ ...gameState, players: updatedPlayers });
    // In a real game, this would trigger a challenge flow
    alert("Challenge initiated! (Mock)");
  };

  const handlePlayAgain = () => {
    setGameState({
      ...gameState,
      screen: 'lobby',
      players: gameState.players.map(p => ({ ...p, cards: [], tokens: 3 })),
      round: 1,
    });
  };

  return (
    <div className="font-sans antialiased bg-[#1a1a2e] min-h-screen text-white selection:bg-[#1DB954] selection:text-black">
      {gameState.screen === 'home' && (
        <Home onHost={handleHost} onJoin={handleJoin} />
      )}
      {gameState.screen === 'lobby' && (
        <Lobby 
          gameState={gameState} 
          currentPlayerId={currentPlayerId} 
          onStart={handleStart} 
          onLeave={handleLeave}
          onUpdateSettings={handleUpdateSettings}
        />
      )}
      {gameState.screen === 'game' && (
        <Game 
          gameState={gameState} 
          currentPlayerId={currentPlayerId} 
          onPlaceCard={handlePlaceCard}
          onSkip={handleSkip}
          onChallenge={handleChallenge}
        />
      )}
      {gameState.screen === 'results' && (
        <Results 
          gameState={gameState} 
          onPlayAgain={handlePlayAgain}
          onHome={handleLeave}
        />
      )}
    </div>
  );
}
